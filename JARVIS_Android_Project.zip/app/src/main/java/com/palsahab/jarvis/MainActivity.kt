package com.palsahab.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var output: TextView
    private lateinit var input: EditText
    private var tts: TextToSpeech? = null
    private val requestAudio = 41
    private val requestSpeech = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
    }

    private fun buildScreen() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(0xFF071521.toInt())
        }

        val title = TextView(this).apply {
            text = "J.A.R.V.I.S"
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(0xFF00D9FF.toInt())
        }
        val subtitle = TextView(this).apply {
            text = "PERSONAL ASSISTANT  •  READY"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(0xFFB7D8E5.toInt())
        }
        output = TextView(this).apply {
            text = "Hello. I am JARVIS.\\nType a command or tap the microphone."
            textSize = 17f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(16, 20, 16, 20)
        }
        val scroll = ScrollView(this).apply {
            addView(output)
        }
        input = EditText(this).apply {
            hint = "Enter a command..."
            setSingleLine(true)
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9BB3C0.toInt())
        }
        val send = Button(this).apply {
            text = "SEND COMMAND"
            setOnClickListener { handleCommand(input.text.toString()) }
        }
        val mic = Button(this).apply {
            text = "🎙  SPEAK TO JARVIS"
            setOnClickListener { startListening() }
        }

        outer.addView(title)
        outer.addView(subtitle)
        outer.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        outer.addView(input)
        outer.addView(send)
        outer.addView(mic)
        setContentView(outer)
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestAudio)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            respond("Speech recognition is not available on this device.")
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
        }
        try {
            startActivityForResult(intent, requestSpeech)
        } catch (_: Exception) {
            respond("Unable to start speech recognition.")
        }
    }

    @Deprecated("Deprecated by Android, retained for compatibility with Android 10")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestSpeech && resultCode == RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val command = words?.firstOrNull().orEmpty()
            input.setText(command)
            handleCommand(command)
        }
    }

    private fun handleCommand(raw: String) {
        val command = raw.trim().lowercase(Locale.ROOT)
        if (command.isEmpty()) {
            respond("Please enter or speak a command.")
            return
        }
        val answer = when {
            "hello" in command || "hi" == command -> "Hello. JARVIS is ready."
            "your name" in command -> "I am JARVIS, your personal assistant."
            "time" in command -> "The current time is " +
                java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(java.util.Date())
            "date" in command -> "Today's date is " +
                java.text.SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault()).format(java.util.Date())
            "status" in command -> "All local JARVIS systems are operational."
            "help" in command -> "Try: hello, what is your name, time, date, or status."
            else -> "I received: $raw. This command needs an AI or device-control module, which we will add next."
        }
        respond(answer)
    }

    private fun respond(message: String) {
        output.text = "JARVIS: $message"
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.getDefault()
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
