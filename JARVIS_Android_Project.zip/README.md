# JARVIS Android Project

This is a starter Android app project for Android 6.0+ (target device: Lenovo TB-X606V / Android 10).

## Included
- JARVIS home screen
- Typed commands
- Android speech-recognition prompt
- Text-to-speech replies
- Basic local commands: hello, name, time, date, status, help

## Build
Upload this project to a GitHub repository. Then open Actions > Build JARVIS APK > Run workflow.
When the workflow completes, open its run page and download the `JARVIS-debug-APK` artifact.
Extract the downloaded ZIP and install `app-debug.apk` on the tablet.

## Important limitations
This starter is not an always-listening wake-word assistant and does not yet control smart devices or provide cloud AI. Those require separate modules, permissions, device integrations, and (for AI) a configured service.
